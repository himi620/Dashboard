1. Open this project in terminal 
2. npm start

if node modules are not available please do npm i before npm start